"""Core data and business rules for Bike Service Log."""

from __future__ import annotations

import csv
import io
import json
import math
import tempfile
import uuid
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import date, timedelta
from pathlib import Path
from typing import Iterable, Mapping


CATEGORIES = (
    "Oil & filter",
    "Brakes",
    "Tires",
    "Chain & drivetrain",
    "Electrical",
    "General tune-up",
    "Other",
)
SERVICE_INTERVAL_DAYS = 180
CSV_FIELDS = ("bike", "date", "odometer_km", "category", "cost", "notes")


@dataclass(frozen=True)
class ServiceRecord:
    id: str
    bike: str
    date: str
    odometer_km: int
    category: str
    cost: float
    notes: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _sample_records() -> list[ServiceRecord]:
    dates = (
        "2025-01-12", "2025-03-08", "2025-05-17", "2025-07-06",
        "2025-09-21", "2025-11-09", "2026-01-18", "2026-03-07",
        "2026-05-16", "2026-07-12", "2026-09-20", "2026-11-08",
    )
    bikes = (("Commuter 01", 1840), ("Trail 29", 920), ("City E-bike", 2460))
    categories = (
        "General tune-up", "Oil & filter", "Brakes", "Chain & drivetrain",
        "Tires", "General tune-up", "Electrical", "Oil & filter",
        "Brakes", "Chain & drivetrain", "General tune-up", "Tires",
    )
    notes = (
        "Routine inspection and safety check",
        "Fresh fluids and filter replacement",
        "Brake pads inspected and adjusted",
        "Chain cleaned, lubricated, and tensioned",
        "Tire pressure and tread checked",
        "Cables adjusted and fasteners tightened",
    )
    costs = (38, 64.5, 52, 29, 86, 34, 47.5, 62, 58, 31, 42, 94)
    records = []
    for bike_index, (bike, starting_odometer) in enumerate(bikes):
        odometer = starting_odometer
        for index, service_date in enumerate(dates):
            odometer += 550 + ((index * 137 + bike_index * 89) % 500)
            records.append(
                ServiceRecord(
                    id=f"demo-{bike_index + 1}-{index + 1:02}",
                    bike=bike,
                    date=service_date,
                    odometer_km=odometer,
                    category=categories[(index + bike_index * 2) % len(categories)],
                    cost=float(costs[(index + bike_index * 3) % len(costs)]),
                    notes=notes[(index + bike_index) % len(notes)],
                )
            )
    return records


def validate_record(
    record: ServiceRecord,
    existing: Iterable[ServiceRecord] = (),
) -> None:
    if not record.id.strip():
        raise ValueError("A record ID is required.")
    if not record.bike.strip() or len(record.bike.strip()) > 60:
        raise ValueError("Enter a bike name between 1 and 60 characters.")
    try:
        service_date = date.fromisoformat(record.date)
    except ValueError as exc:
        raise ValueError("Enter a valid service date.") from exc
    if service_date.isoformat() != record.date:
        raise ValueError("Enter the service date in YYYY-MM-DD format.")
    if service_date > date.today():
        raise ValueError("Service dates cannot be in the future.")
    if isinstance(record.odometer_km, bool) or not isinstance(record.odometer_km, int):
        raise ValueError("Odometer reading must be a whole number.")
    if record.odometer_km < 0:
        raise ValueError("Odometer reading cannot be negative.")
    if record.category not in CATEGORIES:
        raise ValueError("Choose a valid service category.")
    if isinstance(record.cost, bool) or not isinstance(record.cost, (int, float)):
        raise ValueError("Cost must be a number.")
    if not math.isfinite(record.cost) or record.cost < 0:
        raise ValueError("Cost must be a finite amount of zero or more.")
    if len(record.notes) > 500:
        raise ValueError("Notes must be 500 characters or fewer.")

    for previous in existing:
        if previous.id == record.id:
            raise ValueError("A record with this ID already exists.")
        if previous.bike.casefold() != record.bike.casefold():
            continue
        if record.date < previous.date and record.odometer_km > previous.odometer_km:
            raise ValueError("Odometer readings must rise with service dates.")
        if record.date > previous.date and record.odometer_km < previous.odometer_km:
            raise ValueError("Odometer reading is below this bike's previous service.")


def _validate_dataset(records: list[ServiceRecord]) -> None:
    checked: list[ServiceRecord] = []
    for record in sorted(records, key=lambda item: (item.date, item.bike.casefold())):
        validate_record(record, checked)
        checked.append(record)


def save_records(records: Iterable[ServiceRecord], path: Path) -> None:
    items = list(records)
    _validate_dataset(items)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as temporary_file:
            temporary_path = Path(temporary_file.name)
            json.dump(
                [record.to_dict() for record in items],
                temporary_file,
                ensure_ascii=False,
                indent=2,
            )
            temporary_file.write("\n")
        temporary_path.replace(path)
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)


def _record_from_mapping(raw: object) -> ServiceRecord:
    if not isinstance(raw, Mapping):
        raise ValueError("Every saved service record must be a JSON object.")
    try:
        record = ServiceRecord(
            id=raw["id"],
            bike=raw["bike"],
            date=raw["date"],
            odometer_km=raw["odometer_km"],
            category=raw["category"],
            cost=raw["cost"],
            notes=raw["notes"],
        )
    except KeyError as exc:
        raise ValueError(f"Saved record is missing the {exc.args[0]!r} field.") from exc
    if not isinstance(record.id, str) or not isinstance(record.bike, str):
        raise ValueError("Saved record IDs and bike names must be text.")
    if not isinstance(record.date, str) or not isinstance(record.category, str):
        raise ValueError("Saved dates and categories must be text.")
    if not isinstance(record.notes, str):
        raise ValueError("Saved notes must be text.")
    return record


def load_records(path: Path) -> list[ServiceRecord]:
    if not path.exists():
        records = _sample_records()
        save_records(records, path)
        return records
    try:
        raw_records = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Saved data is not valid JSON: {exc.msg}.") from exc
    if not isinstance(raw_records, list):
        raise ValueError("Saved data must contain a list of service records.")
    records = [_record_from_mapping(raw) for raw in raw_records]
    _validate_dataset(records)
    return records


def add_record(
    records: Iterable[ServiceRecord],
    *,
    bike: str,
    service_date: date,
    odometer_km: int,
    category: str,
    cost: float,
    notes: str,
) -> ServiceRecord:
    existing = list(records)
    record = ServiceRecord(
        id=uuid.uuid4().hex,
        bike=bike.strip(),
        date=service_date.isoformat(),
        odometer_km=odometer_km,
        category=category,
        cost=cost,
        notes=notes.strip(),
    )
    validate_record(record, existing)
    return record


def import_csv(
    contents: str,
    existing: Iterable[ServiceRecord] = (),
) -> tuple[list[ServiceRecord], list[str]]:
    reader = csv.DictReader(io.StringIO(contents))
    if reader.fieldnames is None:
        return [], ["The CSV file is empty."]
    missing = [field for field in CSV_FIELDS if field not in reader.fieldnames]
    if missing:
        return [], [f"Missing required CSV columns: {', '.join(missing)}."]

    accepted: list[ServiceRecord] = []
    errors: list[str] = []
    current_records = list(existing)
    for row_number, row in enumerate(reader, start=2):
        try:
            if row is None or not any(value and value.strip() for value in row.values()):
                continue
            record = ServiceRecord(
                id=uuid.uuid4().hex,
                bike=(row.get("bike") or "").strip(),
                date=(row.get("date") or "").strip(),
                odometer_km=int((row.get("odometer_km") or "").strip()),
                category=(row.get("category") or "").strip(),
                cost=float((row.get("cost") or "").strip()),
                notes=(row.get("notes") or "").strip(),
            )
            validate_record(record, current_records + accepted)
            accepted.append(record)
        except (ValueError, TypeError) as exc:
            errors.append(f"Row {row_number}: {exc}")
    return accepted, errors


def service_statuses(
    records: Iterable[ServiceRecord],
    today: date | None = None,
) -> list[dict[str, object]]:
    reference_date = today or date.today()
    latest_by_bike: dict[str, ServiceRecord] = {}
    for record in records:
        current = latest_by_bike.get(record.bike)
        if current is None or record.date > current.date:
            latest_by_bike[record.bike] = record

    statuses = []
    for bike, record in sorted(latest_by_bike.items()):
        due_date = date.fromisoformat(record.date) + timedelta(days=SERVICE_INTERVAL_DAYS)
        days_remaining = (due_date - reference_date).days
        if days_remaining < 0:
            status = "Overdue"
        elif days_remaining <= 30:
            status = "Due soon"
        else:
            status = "On track"
        statuses.append(
            {
                "bike": bike,
                "last_service": record.date,
                "odometer_km": record.odometer_km,
                "due_date": due_date.isoformat(),
                "days_remaining": days_remaining,
                "status": status,
            }
        )
    return statuses


def monthly_spend(records: Iterable[ServiceRecord]) -> list[dict[str, object]]:
    totals: dict[str, float] = defaultdict(float)
    for record in records:
        totals[record.date[:7]] += record.cost
    return [{"month": month, "total": round(total, 2)} for month, total in sorted(totals.items())]


def export_csv(records: Iterable[ServiceRecord]) -> str:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=CSV_FIELDS, lineterminator="\n")
    writer.writeheader()
    for record in sorted(records, key=lambda item: (item.date, item.bike.casefold())):
        writer.writerow({field: getattr(record, field) for field in CSV_FIELDS})
    return output.getvalue()


def export_markdown(records: Iterable[ServiceRecord]) -> str:
    items = sorted(records, key=lambda item: (item.date, item.bike.casefold()), reverse=True)
    total_spend = sum(record.cost for record in items)
    lines = [
        "# Bike Service Log",
        "",
        f"- Records: {len(items)}",
        f"- Total spend: ${total_spend:,.2f}",
        "",
        "| Date | Bike | Service | Odometer (km) | Cost | Notes |",
        "| --- | --- | --- | ---: | ---: | --- |",
    ]
    for record in items:
        notes = record.notes.replace("|", "\\|").replace("\n", " ")
        bike = record.bike.replace("|", "\\|")
        lines.append(
            f"| {record.date} | {bike} | {record.category} | "
            f"{record.odometer_km:,} | ${record.cost:,.2f} | {notes} |"
        )
    return "\n".join(lines) + "\n"
