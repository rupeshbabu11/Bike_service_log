# Bike Service Log

A beginner-friendly Streamlit app for tracking bike maintenance, odometer readings, and service costs. It runs locally and stores records in `data/service_records.json`; no account or hosted service is required.

## Run the demo

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

The first launch creates a local log with 36 realistic sample visits across three bikes. The log lives beside the app and stays available after restarting it.

## What to try

1. Open **Overview** to see service reminders and monthly spending.
2. Open **Add service** and record a tune-up. Dates, mileage, cost, and notes are checked before saving.
3. Use **Service log** to search and filter the history.
4. Open **Insights & export** to download a CSV or Markdown report, or import another CSV.
5. Restart the app to confirm that the local JSON log persisted.

For CSV import, include these columns: `bike,date,odometer_km,category,cost,notes`. Dates use `YYYY-MM-DD`; invalid rows are reported without discarding valid rows.

## Tests

```powershell
python -m unittest discover -s tests -v
```

## Data and privacy

The app reads and writes only the local JSON file under `data/`. The sample log is created on first launch; once created, it is not replaced on later launches.
