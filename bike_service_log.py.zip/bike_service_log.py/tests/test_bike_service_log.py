import csv
import json
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

from bike_service_log import (
    CATEGORIES,
    ServiceRecord,
    add_record,
    export_csv,
    import_csv,
    load_records,
    save_records,
    service_statuses,
)


def record(
    *,
    record_id: str = "one",
    bike: str = "City bike",
    service_date: str = "2026-01-10",
    odometer: int = 1200,
    cost: float = 45.0,
) -> ServiceRecord:
    return ServiceRecord(
        id=record_id,
        bike=bike,
        date=service_date,
        odometer_km=odometer,
        category=CATEGORIES[0],
        cost=cost,
        notes="Routine check",
    )


class ServiceLogTests(unittest.TestCase):
    def test_first_load_creates_persistent_demo_dataset(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "data" / "services.json"

            first_load = load_records(path)
            second_load = load_records(path)

            self.assertEqual(len(first_load), 36)
            self.assertEqual(first_load, second_load)
            self.assertTrue(path.is_file())

    def test_add_rejects_odometer_lower_than_previous_service(self) -> None:
        with self.assertRaisesRegex(ValueError, "below this bike's previous service"):
            add_record(
                [record()],
                bike="City bike",
                service_date=date(2026, 2, 1),
                odometer_km=1100,
                category=CATEGORIES[0],
                cost=20,
                notes="",
            )

    def test_add_rejects_future_dates_and_invalid_costs(self) -> None:
        with self.assertRaisesRegex(ValueError, "future"):
            add_record(
                [],
                bike="City bike",
                service_date=date.today() + timedelta(days=1),
                odometer_km=0,
                category=CATEGORIES[0],
                cost=20,
                notes="",
            )
        with self.assertRaisesRegex(ValueError, "finite amount"):
            add_record(
                [],
                bike="City bike",
                service_date=date.today(),
                odometer_km=0,
                category=CATEGORIES[0],
                cost=float("inf"),
                notes="",
            )

    def test_csv_import_keeps_valid_rows_and_reports_bad_rows(self) -> None:
        contents = (
            "bike,date,odometer_km,category,cost,notes\n"
            "City bike,2026-02-01,1300,Brakes,25,New pads\n"
            "City bike,not-a-date,1400,Brakes,25,Bad date\n"
        )

        imported, errors = import_csv(contents, [record()])

        self.assertEqual(len(imported), 1)
        self.assertEqual(imported[0].odometer_km, 1300)
        self.assertEqual(len(errors), 1)
        self.assertIn("Row 3", errors[0])

    def test_csv_export_round_trips_records(self) -> None:
        contents = export_csv([record()])
        rows = list(csv.DictReader(contents.splitlines()))

        self.assertEqual(rows[0]["bike"], "City bike")
        self.assertEqual(rows[0]["odometer_km"], "1200")
        self.assertEqual(rows[0]["cost"], "45.0")

    def test_corrupt_json_is_reported_instead_of_overwritten(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "services.json"
            path.write_text("{broken", encoding="utf-8")

            with self.assertRaisesRegex(ValueError, "not valid JSON"):
                load_records(path)
            self.assertEqual(path.read_text(encoding="utf-8"), "{broken")

    def test_status_reports_overdue_service(self) -> None:
        old_record = record(service_date="2025-01-01")
        statuses = service_statuses([old_record], today=date(2026, 1, 1))

        self.assertEqual(statuses[0]["status"], "Overdue")


if __name__ == "__main__":
    unittest.main()
