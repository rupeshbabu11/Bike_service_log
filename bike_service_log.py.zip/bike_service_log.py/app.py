from __future__ import annotations

from datetime import date
from pathlib import Path

import streamlit as st

from bike_service_log import (
    CATEGORIES,
    SERVICE_INTERVAL_DAYS,
    ServiceRecord,
    add_record,
    export_csv,
    export_markdown,
    import_csv,
    load_records,
    monthly_spend,
    save_records,
    service_statuses,
)


DATA_FILE = Path(__file__).parent / "data" / "service_records.json"

st.set_page_config(
    page_title="Bike Service Log",
    page_icon="🚲",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    :root { --ink: #172f30; --muted: #748581; --green: #237b62; }
    .stApp { background: #f5f7f5; color: var(--ink); }
    [data-testid="stSidebar"] { background: #edf2ee; border-right: 1px solid #e1e9e2; }
    [data-testid="stSidebar"] > div:first-child { padding-top: 1.4rem; }
    .brand { display:flex; align-items:center; gap:12px; margin-bottom:8px; }
    .brand-mark { width:42px; height:42px; display:grid; place-items:center;
        border-radius:14px; background:#d9ece2; font-size:23px; }
    .brand-name { font-size:18px; font-weight:750; letter-spacing:-.4px; color:#173b32; }
    .brand-caption { color:#71827b; font-size:12px; margin-top:1px; }
    .eyebrow { color:#268064; text-transform:uppercase; letter-spacing:1.6px;
        font-size:11px; font-weight:750; }
    .hero { border-radius:22px; padding:30px 34px; margin:4px 0 22px;
        background:linear-gradient(112deg,#183d34 0%,#23674e 68%,#418268 100%);
        color:#fff; box-shadow:0 12px 30px rgba(27,76,58,.12); }
    .hero h1 { color:#fff; font-size:32px; letter-spacing:-1px; margin:8px 0 7px; }
    .hero p { color:#d5e8dc; max-width:650px; margin:0; font-size:15px; }
    .hero-kicker { color:#bee0c8; font-size:12px; font-weight:700; letter-spacing:1.5px;
        text-transform:uppercase; }
    .section-title { font-size:20px; font-weight:720; letter-spacing:-.4px; margin:16px 0 4px; }
    .section-note { color:#748581; font-size:13px; margin-bottom:12px; }
    [data-testid="stMetric"] { background:white; border:1px solid #e7ece8;
        border-radius:16px; padding:16px 18px; box-shadow:0 4px 16px rgba(33,57,45,.035); }
    [data-testid="stMetricLabel"] { color:#72817b; }
    [data-testid="stMetricValue"] { color:#173b32; }
    div[data-testid="stForm"] { background:white; border:1px solid #e7ece8;
        border-radius:16px; padding:20px; }
    .status-pill { color:#237b62; font-weight:700; }
    </style>
    """,
    unsafe_allow_html=True,
)


def money(value: float) -> str:
    return f"${value:,.2f}"


def show_page_heading(title: str, subtitle: str) -> None:
    st.markdown(f'<div class="section-title">{title}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="section-note">{subtitle}</div>', unsafe_allow_html=True)


try:
    records = load_records(DATA_FILE)
except (OSError, ValueError) as exc:
    st.error(f"Could not open the local service log: {exc}")
    st.info("Check data/service_records.json, then restart the app.")
    st.stop()

with st.sidebar:
    st.markdown(
        """
        <div class="brand">
          <div class="brand-mark">🚲</div>
          <div><div class="brand-name">Spoke & Wrench</div>
          <div class="brand-caption">Your bike, in good hands.</div></div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.markdown("---")
    page = st.radio(
        "WORKSPACE",
        ("Overview", "Service log", "Add service", "Insights & export"),
        label_visibility="visible",
    )
    st.markdown("---")
    st.caption(f"📁 Local log · {len(records)} saved records")
    st.caption(f"🔧 Service check every {SERVICE_INTERVAL_DAYS} days")

st.markdown('<div class="eyebrow">PERSONAL BIKE CARE</div>', unsafe_allow_html=True)
st.title(page)
st.caption("A clear, local-first view of every tune-up, part, and ride.")


if page == "Overview":
    statuses = service_statuses(records)
    total_spend = sum(record.cost for record in records)
    latest_record = max(records, key=lambda item: item.date) if records else None
    overdue_count = sum(item["status"] == "Overdue" for item in statuses)
    due_soon_count = sum(item["status"] == "Due soon" for item in statuses)

    st.markdown(
        """
        <div class="hero">
          <div class="hero-kicker">The little things keep you rolling</div>
          <h1>Every ride starts with a bike that's ready.</h1>
          <p>Keep service dates, mileage, and maintenance costs in one tidy place.
          No accounts, no setup — just your records, saved on this computer.</p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    metric_columns = st.columns(4)
    metric_columns[0].metric("Service visits", f"{len(records):,}")
    metric_columns[1].metric("Bikes tracked", f"{len(statuses):,}")
    metric_columns[2].metric("Total spent", money(total_spend))
    metric_columns[3].metric(
        "Service reminders",
        f"{overdue_count + due_soon_count}",
        delta=f"{overdue_count} overdue",
        delta_color="inverse" if overdue_count else "off",
    )

    chart_column, status_column = st.columns([1.45, 1])
    with chart_column:
        show_page_heading("Maintenance spend", "Your service costs by month.")
        spend_data = monthly_spend(records)
        if spend_data:
            st.bar_chart(spend_data, x="month", y="total", color="#38866a")
        else:
            st.info("Add a service record to see your spending trend.")
    with status_column:
        show_page_heading("Bike check-in", "A reminder is based on 180 days between services.")
        if statuses:
            for item in statuses:
                status = str(item["status"])
                icon = "🔴" if status == "Overdue" else "🟠" if status == "Due soon" else "🟢"
                remaining = int(item["days_remaining"])
                when = f"{abs(remaining)} days overdue" if remaining < 0 else f"{remaining} days left"
                with st.container(border=True):
                    st.markdown(f"**{icon} {item['bike']}**")
                    st.caption(
                        f"Last visit {item['last_service']} · {int(item['odometer_km']):,} km"
                    )
                    st.caption(f"{status} · {when}")
        else:
            st.info("Your bike check-ins will appear here.")

    if latest_record is not None:
        show_page_heading("Latest service", "The most recent entry in your log.")
        st.markdown(
            f"**{latest_record.bike}** · {latest_record.category} · "
            f"{latest_record.date} · {latest_record.odometer_km:,} km · "
            f"{money(latest_record.cost)}"
        )


elif page == "Service log":
    show_page_heading("Service history", "Search, filter, and review every visit.")
    filter_columns = st.columns([1, 1, 1.4])
    bikes = sorted({record.bike for record in records}, key=str.casefold)
    selected_bike = filter_columns[0].selectbox("Bike", ["All bikes", *bikes])
    selected_category = filter_columns[1].selectbox("Service type", ["All types", *CATEGORIES])
    query = filter_columns[2].text_input("Search notes", placeholder="Try 'brakes' or 'inspection'")

    filtered_records = [
        record for record in records
        if (selected_bike == "All bikes" or record.bike == selected_bike)
        and (selected_category == "All types" or record.category == selected_category)
        and (
            not query.strip()
            or query.casefold() in " ".join(
                (record.bike, record.category, record.notes, record.date)
            ).casefold()
        )
    ]
    filtered_records.sort(key=lambda item: (item.date, item.bike.casefold()), reverse=True)
    st.caption(f"{len(filtered_records)} matching visits")
    if filtered_records:
        st.dataframe(
            [
                {
                    "Date": record.date,
                    "Bike": record.bike,
                    "Service": record.category,
                    "Odometer": f"{record.odometer_km:,} km",
                    "Cost": money(record.cost),
                    "Notes": record.notes,
                }
                for record in filtered_records
            ],
            use_container_width=True,
            hide_index=True,
        )
        with st.expander("Remove a record"):
            record_ids = {f"{record.date} · {record.bike} · {record.category}": record.id
                          for record in filtered_records}
            selected_label = st.selectbox("Choose a service visit", list(record_ids))
            if st.button("Delete selected visit", type="secondary"):
                updated_records = [
                    record for record in records if record.id != record_ids[selected_label]
                ]
                save_records(updated_records, DATA_FILE)
                st.success("Service visit removed.")
                st.rerun()
    else:
        st.info("No visits match those filters. Try another bike or search term.")


elif page == "Add service":
    show_page_heading("Add a service visit", "A few details now make the next check-in easier.")
    existing_bikes = sorted({record.bike for record in records}, key=str.casefold)
    bike_choice = st.selectbox("Bike", [*existing_bikes, "＋ Add a new bike"])
    if bike_choice == "＋ Add a new bike":
        bike_name = st.text_input("New bike name", placeholder="e.g. Weekend gravel bike")
        default_odometer = 0
    else:
        bike_name = bike_choice
        latest_for_bike = max(
            (record for record in records if record.bike == bike_choice),
            key=lambda item: item.date,
            default=None,
        )
        default_odometer = latest_for_bike.odometer_km if latest_for_bike else 0

    with st.form("add_service_form", clear_on_submit=False):
        form_columns = st.columns(2)
        service_date = form_columns[0].date_input("Service date", value=date.today(), max_value=date.today())
        odometer = form_columns[1].number_input(
            "Odometer (km)",
            min_value=0,
            value=default_odometer,
            step=100,
            help="Use the reading shown on your bike's odometer.",
        )
        category = form_columns[0].selectbox("Service type", CATEGORIES)
        cost = form_columns[1].number_input(
            "Cost",
            min_value=0.0,
            value=0.0,
            step=5.0,
            format="%.2f",
        )
        notes = st.text_area("Maintenance notes", placeholder="Parts replaced, checks completed, or anything to remember.", max_chars=500)
        submitted = st.form_submit_button("Save service visit", type="primary", use_container_width=True)

    if submitted:
        try:
            record = add_record(
                records,
                bike=bike_name,
                service_date=service_date,
                odometer_km=int(odometer),
                category=category,
                cost=cost,
                notes=notes,
            )
            save_records([*records, record], DATA_FILE)
        except (OSError, ValueError) as exc:
            st.error(f"Service visit was not saved: {exc}")
        else:
            st.success(f"Saved the {category.lower()} visit for {bike_name.strip()}.")
            st.rerun()


elif page == "Insights & export":
    show_page_heading("Insights & export", "Useful numbers and portable reports, all from your local log.")
    import_feedback = st.session_state.pop("import_feedback", None)
    if import_feedback is not None:
        st.success(f"Imported {import_feedback['imported']} service visit(s).")
        for row_error in import_feedback["errors"]:
            st.warning(row_error)

    statuses = service_statuses(records)
    summary_columns = st.columns(4)
    summary_columns[0].metric("Total service spend", money(sum(record.cost for record in records)))
    summary_columns[1].metric(
        "Average visit",
        money(sum(record.cost for record in records) / len(records)) if records else "$0.00",
    )
    summary_columns[2].metric("Overdue bikes", sum(item["status"] == "Overdue" for item in statuses))
    summary_columns[3].metric("Due in 30 days", sum(item["status"] == "Due soon" for item in statuses))

    show_page_heading("Spend over time", "Monthly totals, grouped by the service date.")
    spend_data = monthly_spend(records)
    if spend_data:
        st.line_chart(spend_data, x="month", y="total", color="#38866a")
    else:
        st.info("Add a few visits to build your spending trend.")

    st.markdown("#### Download a report")
    export_columns = st.columns(2)
    export_columns[0].download_button(
        "Download CSV",
        data=export_csv(records),
        file_name="bike-service-log.csv",
        mime="text/csv",
        use_container_width=True,
    )
    export_columns[1].download_button(
        "Download Markdown summary",
        data=export_markdown(records),
        file_name="bike-service-report.md",
        mime="text/markdown",
        use_container_width=True,
    )

    st.markdown("#### Import an existing CSV")
    st.caption("Required columns: bike, date, odometer_km, category, cost, notes.")
    uploaded_file = st.file_uploader("Choose a service log CSV", type=["csv"], label_visibility="collapsed")
    if uploaded_file is not None and st.button("Import valid rows", type="secondary"):
        try:
            contents = uploaded_file.getvalue().decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            st.error(f"Could not read the CSV as UTF-8: {exc}")
        else:
            imported, row_errors = import_csv(contents, records)
            if imported:
                try:
                    save_records([*records, *imported], DATA_FILE)
                except (OSError, ValueError) as exc:
                    st.error(f"Could not save imported rows: {exc}")
                else:
                    st.session_state["import_feedback"] = {
                        "imported": len(imported),
                        "errors": row_errors,
                    }
                    st.rerun()
            if row_errors:
                st.warning(f"{len(row_errors)} row(s) were skipped:")
                for row_error in row_errors:
                    st.write(f"- {row_error}")
